attach(salamander)
names(salamander)

#a
plot(Years,Number)

#b
glm.obj<-glm(Number~Years,data =salamander,family=poisson());glm.obj
#log(lambda)= 0.59136+*YEARS


#c
points(Years,glm.obj$fitted.values,type = "p",col="red")

#d
glm.obj2<-glm(Number~Years+I(Years^2),data =salamander,family=poisson());glm.obj2
anova(glm.obj,glm.obj2,test = "Chisq")
