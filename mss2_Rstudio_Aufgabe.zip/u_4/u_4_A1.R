# Aufgabe 1
# a
Temp <- c(66, 70, 69, 68, 67, 72, 73, 70, 57, 63, 70, 78, 67,
          53, 67, 75, 70, 81, 76, 79, 75, 76, 58)
Failure <- c(0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 0,
             0, 0, 0, 0, 1, 0, 1)
datf<-data.frame(Temp,Failure)

# b
fit<-glm(Failure~ Temp,data =datf,family = binomial);fit


#c
summary(fit)
fit$coefficients

#d
#H0 : β1 = 0 gegen H1 : β1 != 0

#e signifikanz < 0.5 i.e 0.0320

#f
confint(fit,"Temp")

#g
fit$coefficients
confint(fit)
linpred<-fit$linear.predictors;linpred
fit$fitted.values
vcov(fit)
pi<-exp(linpred) /(1+exp(linpred)) 
plot(Temp,pi)

#h
newx<-data.frame(Temp=50:85)
prognose<-predict(fit,newdata=newx)
plot(newx$Temp,prognose)

prognose<-predict(fit,newdata=newx,type="response")
plot(newx$Temp,prognose)
