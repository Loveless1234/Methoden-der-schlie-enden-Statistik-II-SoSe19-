#Aufgabe 2

#a
load("/Users/ranjitsah/Documents/SS_ 2019/Mss2/u_4/banknote.Rda")

#b
Banknote.logreg<-glm(Y~Length+Left+Right+Bottom+Top,
                     family=binomial,data=banknote)
Banknote.logreg

#c
par(mfrow=c(1,6))
for(i in 1:6) {
  boxplot(banknote[,i], main=names(banknote)[i])
}
#p -value< alpha⇒reject H0
# p-value≥⇒fail to reject HH0

#d
summary(Banknote.logreg)
Banknote.logreg$coefficients

#e
Banknote.logreg<-glm(Y~Bottom+Top,
                     family=binomial,data=banknote)
Banknote.logreg
summary(Banknote.logreg)


#Aufgabe 3
#(a) Botton 9.0, Top 9.7

#d
5.600
7.428

#e
exp(5.600)
exp(7.428)

#f
exp(7.428)
exp(5.600)
exp(5.6+7.428)



Scheine<-c("A","B","C","D")
ObererRand<-c("t","t+1","t","t+1")
UntererRand<-c("b","b","b+1","b+1")
ma<-data.frame(Scheine,ObererRand,UntererRand)

new_konto<-glm(Y~Bottom+Top,
      family=binomial,data=banknote)
summary(new_konto)


