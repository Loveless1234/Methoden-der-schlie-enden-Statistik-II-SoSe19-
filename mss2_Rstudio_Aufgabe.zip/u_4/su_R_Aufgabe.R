Beispiel.df<-data.frame(Status=rep(c(1,0,1,0),c(20,2,5,5)),Faktor=rep(c("a","b"),c(22,10)))
Beispiel.df
table(Beispiel.df)
glm.obj<-glm(Status~Faktor,data =Beispiel.df, family=binomial)
summary(glm.obj)


Beisp.mat<-matrix(c(20,5,2,5),2)
row.names(Beisp.mat)<-letters[1:2]
faktor<-as.factor(letters[1:2])
faktor
glm(Beisp.mat~faktor,family = binomial())
