#Muster Code f?r ?bungsblatt 4 

#Erg?nzen Sie die L?cken

#Aufgabe 2

beta<-matrix(c(0,0),2,1)
x<-0:4
y<-c(0,1,0,1,1)
linPred<-beta[1]+beta[2]*x
pi<-exp(linPred) /(1+exp(linPred))  #Formel f?r pi_i als eine Ausdruck mit linpred
S<-matrix(c(sum(y)-sum(pi),sum(y*x)-sum(pi*x)),2,1)     #Scorefunktion siehe Vorlesungsskript

#Hessematrix
H<- -1*(matrix(c(sum(pi*(1-pi)*1),sum(pi*(1-pi)*x),sum(pi*(1-pi)*x),sum(pi*(1-pi)*x^2)),2,2))

#Tipp: Iverse von H ist solve(H)
beta<-beta-solve(H)%*%S 
print(beta)     ##Was sind die neue neue beta Werte?  
                ##passen sie zur L?sung aus Aufgabe 1?

linPred<-beta[1]+beta[2]*x  #Aktualisierte linearen Prädiktor
pi<-exp(linPred) /(1+exp(linPred))        #Aktualisierte E(Y)


### Stelle die prognose und angepasste Werte grafisch dar.
xx<-seq(-2,6,0.01)     
linPredxx<-beta[1]+beta[2]*xx
plot(xx,linPredxx,type="l")
plot(x,pi)

##Aufgabe 3
#jetzt mit einer "while" Schleife
beta<-matrix(c(0,0),2,1)
x<-0:4
y<-c(0,1,0,1,1)

Diff<-Inf
while(Diff>1E-6){
  linPred<-beta[1]+beta[2]*x
  pi<-exp(linPred) /(1+exp(linPred))
  S<-matrix(c(sum(y)-sum(pi),sum(y*x)-sum(pi*x)),2,1)
  H<- -1*(matrix(c(sum(pi*(1-pi)*1),sum(pi*(1-pi)*x),sum(pi*(1-pi)*x),sum(pi*(1-pi)*x^2)),2,2))
  betanew<-beta-solve(H)%*%S 
  Diff<-abs(betanew-beta)
  beta<-betanew
}
##die neue beta sind
beta

### Stelle die prognose und angepasste Werte grafisch dar.
xx<-seq(-2,6,0.01)     
linPredxx<-betanew[1]+betanew[2]*xx
plot(xx,linPredxx,type="l")
plot(x,pi)


##Aufgabe 4  Challenger Katastrophe

x<-Temp <- c(66, 70, 69, 68, 67, 72, 73, 70, 57, 63, 70, 78, 67, 
             53, 67, 75, 70, 81, 76, 79, 75, 76, 58)
y<-Failure <- c(0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 0, 
                0, 0, 0, 0, 1, 0, 1)
datf<-data.frame(x,y)
fit<-glm(y ~ x,data = datf,family = binomial)
summary(fit)
fit$coefficients
confint(fit)

beta<-matrix(c(0,0),2,1)
Diff<-Inf
while(Diff>1E-6){
  linPred<-beta[1]+beta[2]*x
  pi<-exp(linPred) /(1+exp(linPred)) 
  S<-matrix(c(sum(y)-sum(pi),sum(y*x)-sum(pi*x)),2,1) 
  H<- -1*(matrix(c(sum(pi*(1-pi)*1),sum(pi*(1-pi)*x),sum(pi*(1-pi)*x),sum(pi*(1-pi)*x^2)),2,2)) 
  
  betanew<-beta-solve(H)%*%S
  Diff<-max(abs(betanew-beta))
  beta<-betanew
}
beta


### Stelle die Prognosen und angepassten Werte grafisch dar.
xx<-seq(50,85,0.01)     
linPredxx<-beta[1]+beta[2]*xx
plot(xx,linPredxx,type="l")
plot(x,pi)

####Bestimme ein 95% KI f?r beta[2]
confint(fit)
B_j<- -0.2321627 
root_var<-sqrt(0.01171514)
KI<-B_j+c(-1,1)*1.96*root_var
KI
