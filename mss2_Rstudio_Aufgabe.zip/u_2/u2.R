Temp <-c(66, 70, 69, 68, 67, 72, 73, 70, 57, 63, 70, 78, 67,53, 67, 75, 70, 81, 76, 79, 75, 76, 58)

Failure <- c(0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1)

#a
plot(Temp,Failure,xlab = "Temepature",ylab = "Failure")

t<-table(Failure,Temp)
t

prop.table(t)
prop.table(t,1)
prop.table(t,2)

t2<-table(Failure,cut(Temp,breaks =seq(52,82,by=5),right = FALSE))
t2

prop.table(t2)
prop.table(t2,1)
phat<-prop.table(t2,2)


t3<-table(Temp,cut(Temp,breaks =seq(52,82,by=5),right = FALSE))
t3
prop.table(t3)
prop.table(t3,1)
Gruppenmittel<-prop.table(t3,2)


plot(phat,Gruppenmittel)

funfitlogit<-function(beta,d,y) sum((y-exp(beta[1]+beta[2]*d)/(+ 1+exp(beta[1]+beta[2]*d)))^2)
nlm(funfitlogit,c(0.01,0.01),d=0.01,y=-0.01  )


glm(Failure~Temp)







