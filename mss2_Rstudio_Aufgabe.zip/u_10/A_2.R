#UEbung 11 Aufgabe 2
library(MASS)
Melanoma
View(Melanoma)
attach(Melanoma)
names(Melanoma)
