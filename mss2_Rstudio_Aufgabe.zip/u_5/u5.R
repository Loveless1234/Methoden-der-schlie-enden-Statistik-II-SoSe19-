library(titanic)
tab <- Titanic[1:3,,"Adult",]
tab
tab <- as.matrix(ftable(tab))
tab
klasse <- as.factor(rep(c("1te","2te","3te"), each=2))
klasse
geschl <- as.factor(rep(c("M","F"), 3))
data.frame(tab,klasse,geschl)
classsexmod <- glm(tab ~ geschl + klasse, family=binomial)
summary(classsexmod)

null <- glm(tab~ 1, family = "binomial", data =Titanic)
null
