#su aufgabe 1
#Beispiel: Schmerzlinderung mit Ibuprofen
Treat<-c(1,0)
Response<-matrix(c(22,18,7,33),2,2,byrow=T)
log.reg<-glm(Response~Treat,family=binomial)
log.reg


##Odds-Ratio: logistisch Regression
Vorstrafen.tab<- matrix(c(10, 2, 3, 15), nrow = 2,
                        dimnames = list(Zwilling=c("monozygotisch","dizygotisch"), Status=c("vorbest","nicht")))
Zwilling<-as.factor(c("mono","di"))
glm(Vorstrafen.tab~Zwilling,family=binomial)
