#aufgaben Blatt 1
# Linear Regression 
names(Grillen)
attach(Grillen)
fit<-lm(Hwt~Bwt,data = cats)
fit
summary(fit)
plot(fit)
abline(fit,col="blue")

fit2<-lm(Hwt~Bwt,subset(cats,Sex=="M"))
fit2
summary(fit2)
plot(fit2)
abline(fit2,col="orange")

fit3<-lm(Hwt~Bwt,subset(cats,Sex=="F"))
fit3
summary(fit3)
plot(fit3)
abline(fit3,col="green")

anova(lm(fit))
ancova

y_schatzer<-(-0.3567*2.8)+4.0341
y_schatzer

y2_schatzer<-(-1.184*2.8)+4.313
y2_schatzer

y3_schatzer<-(2.981*2.8)+2.636
y3_schatzer


