#Aufgabe 2 Geburtsgewicht
#a
library(MASS)

#b
attach(birthwt)
race <- factor(race, labels = c("white", "black", "other"))
ptd <- factor(ptl > 0)
ftv <- factor(ftv)
levels(ftv)[-(1:2)] <- "2+"
birthwt2<-data.frame(low=factor(low),age,lwt,race,
                     smoke=as.factor(smoke>0),ptd,ht=as.factor(ht>0),
                     ui=as.factor(ui>0),ftv)
detach(birthwt)
attach(birthwt2)

#c
Nullmodell<-glm(low~1,data = birthwt2,family = binomial())
#d
add1(Nullmodell, scope=low~age+lwt+race+smoke+ptd+ht+ui+ftv,test="Chisq")
AIC(Nullmodell)
#f
M1<-glm(low~ptd,data = birthwt2,family = binomial())
add1(M1, scope=low~age+lwt+race+smoke+ptd+ht+ui+ftv,test="Chisq")
AIC(M1)

M2<-glm(low~ptd+age,data = birthwt2,family = binomial())
add1(M2, scope=low~age+lwt+race+smoke+ptd+ht+ui+ftv,test="Chisq")
AIC(M2)

M3<-glm(low~ptd+age+ht,data = birthwt2,family = binomial())
add1(M3, scope=low~age+lwt+race+smoke+ptd+ht+ui+ftv,test="Chisq")
AIC(M3)

M4<-glm(low~ptd+age+ht+lwt,data = birthwt2,family = binomial())
add1(M4, scope=low~age+lwt+race+smoke+ptd+ht+ui+ftv,test="Chisq")
AIC(M4)


#e
#AIC(M5) 225.8978 iste die best modell mit ptd Variable

#g
plot(allEffects(M4))

#h
summary(M4)
add1(M4, scope=low~age+lwt+race+smoke+ptd+ht+ui+ftv,k=log(189),test="Chisq")
#wir bekommen kein glech modell 
