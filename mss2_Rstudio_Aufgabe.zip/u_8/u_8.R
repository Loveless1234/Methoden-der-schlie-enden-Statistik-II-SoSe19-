#AufgabenBlatt 8
#Aufgabe 1

#a
vasoconstrictio<-read.table(file.choose(),header = T)
attach(vasoconstrictio)

#b
par(mfrow=c(1,2))
for(i in 1:2) {
  boxplot(vasoconstrictio[,i]~vaso, main=names(vasoconstrictio)[i],xlab="vaso",ylab="volume",col="#94d639")
}

#c
Nullmod<-glm(vaso~1,data = vasoconstrictio,family = binomial());Nullmod

#d 
#i
add1(Nullmod, scope=vaso ~ volume + rate,test="Chisq")
AIC(Nullmod)

#ii)

M1<-glm(vaso~volume,family = binomial());M1
add1(M1, scope=vaso ~ volume + rate,test="Chisq")
AIC(M1)

M2<-glm(vaso~rate,family = binomial());M2
add1(M2, scope=vaso ~ volume + rate,test="Chisq")
AIC(M2)

##volume variable hat kleinste AIC wert 50.98938

#f
fit.obj<-glm(vaso ~ volume + rate,family = binomial())
summary(fit.obj)

#g
-9.5536+3.8907*volume+  2.6561*rate

#h
vaso.lin.pedict<-fit.obj$linear.predictors
vaso.angepasst<-fit.obj$fitted.values

pos.prog<-(vaso.angepasst>0.5)

table(pos.prog,vaso)









#h
















