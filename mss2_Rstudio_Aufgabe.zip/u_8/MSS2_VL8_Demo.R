#Demo In VL 8


#AIC mit Titanic
tab<-ftable(Titanic)
tab
Geschl <- gl(2,2,16,labels=c("M","F"))
Alter <- gl(2,1,16,labels=c("C","A"))
Klasse <-gl(4,4,16,labels=c("1st","2nd","3rd","Crew"))



Nullmod <- glm(tab ~ 1, family=binomial)
summary(Nullmod)
add1(Nullmod,scope=tab~Geschl+Klasse+Alter,test="Chisq")

Aktmod <- glm(tab ~ Geschl, family=binomial)
summary(Aktmod)
add1(Aktmod,scope=tab~Geschl+Klasse+Alter,test="Chisq")


Aktmod <- glm(tab ~ Geschl+Klasse, family=binomial)
add1(Aktmod,scope=tab~Geschl+Klasse+Alter,test="Chisq")


Aktmod <- glm(tab ~ Geschl+Klasse+Alter, family=binomial)
summary(Aktmod)

add1(Aktmod,scope=tab~Geschl*Klasse*Alter,test="Chisq")
Aktmod <- glm(tab ~ Geschl+Klasse+Alter+Geschl:Klasse, family=binomial)
add1(Aktmod,scope=tab~Geschl*Klasse*Alter,test="Chisq")

Aktmod <- glm(tab ~ Geschl+Klasse+Alter+Geschl:Klasse+Klasse:Alter, family=binomial)
summary(Aktmod)
add1(Aktmod,scope=tab~Geschl*Klasse*Alter,test="Chisq")

##Scope Beispiel
Aktmod <- glm(tab ~ Geschl+Klasse, family=binomial)
#summary(Aktmod)
add1(Aktmod,scope=tab~Geschl*Klasse*Alter,test="Chisq")
#Wechselwirkungen mit Alter sind keine Option


#BIC
Nullmod <- glm(tab ~ 1, family=binomial)
add1(Nullmod,scope=tab~Geschl+Klasse+Alter,k=log(2201),test="Chisq")
Aktmod <- glm(tab ~ Geschl, family=binomial)
add1(Aktmod,scope=tab~Geschl+Klasse+Alter,k=log(2201),test="Chisq")
Aktmod <- glm(tab ~ Geschl+Klasse, family=binomial)
add1(Aktmod,scope=tab~Geschl+Klasse+Alter,k=log(2201),test="Chisq")
Aktmod <- glm(tab ~ Geschl+Klasse+Alter, family=binomial)
add1(Aktmod,scope=tab~Geschl*Klasse*Alter,k=log(2201),test="Chisq")
Aktmod <- glm(tab ~ Geschl+Klasse+Alter+Geschl:Klasse, family=binomial)
add1(Aktmod,scope=tab~Geschl*Klasse*Alter,k=log(2201),test="Chisq")

Aktmod <- glm(tab ~ Geschl+Klasse+Alter+Geschl:Klasse+Klasse:Alter, family=binomial)
#summary(Aktmod)
add1(Aktmod,scope=tab~Geschl*Klasse*Alter,k=log(2201),test="Chisq")

