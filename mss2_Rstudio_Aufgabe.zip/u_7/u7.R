#a
tab<-ftable(Titanic)
tab

#b
Geschl <- gl(2,2,16,labels=c("Male","Female"));Geschl
Alter <- gl(2,1,16,labels=c("Child","Adult"));Alter
Klasse <-gl(4,4,16,labels=c("1st","2nd","3rd","Crew"));Klasse

#c
tab
Klasse
#d

library(effects)
M1<-glm(tab~Klasse,family = binomial(),data = Titanic);M1
plot(allEffects(M1))

#e
M2<-glm(tab~Klasse+Geschl,family = binomial(),data = Titanic);M2
plot(allEffects(M2))
anova(M1,M2,test="Chisq")
M3<-glm(tab~Klasse+Geschl+Alter,family = binomial(),data = Titanic);M3
plot(allEffects(M3))
anova(M2,M3,test="Chisq")

#f
M4<-glm(tab~(Klasse+Geschl+Alter)^2,family = binomial(),data = Titanic);M4
anova(M4,M3,test="Chisq")
M5<-glm(tab~(Klasse+Geschl+Alter+Klasse:Geschl+Klasse:Alter),family = binomial(),data = Titanic);M5

#g
M6<-glm(tab~Geschl*Alter*Klasse,family = binomial(),data = Titanic);M6
anova(M6,M4,test="Chisq")
library(carData)
anova(M6)

#h
plot(allEffects(M6))
