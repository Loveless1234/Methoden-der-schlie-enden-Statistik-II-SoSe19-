load("Documents/SS_ 2019/Mss2/u_6/BBBClub.rda")
attach(BBBClub)
BBBClub$lastmonth<-as.factor(BBBClub$last==1);BBBClub$lastmonth
summary(BBBClub)
fit<-glm(lastmonth~choice+gender,family = binomial());fit
plot(allEffects(fit))


fit<-glm(BBBClub~choice+gender,family = binomial(),data = BBBClub)

glm.obj<-glm(choice~gender,family = binomial(),data = BBBClub);glm.obj
plot(allEffects(glm.obj))

glm.obj2<-glm(choice~lastmonth,family = binomial(),data = BBBClub);glm.obj2
glm.obj3<-glm(choice~lastmonth+gender,family = binomial(),data = BBBClub);glm.obj3
plot(allEffects(glm.obj3))

#Aufgabe 3
strepto<-matrix(c(19,29,24,497,560,269),3,2);strepto
kind<-strepto[1:3,1]
boxplot(strepto~kind)
size<-factor(1:3,labels=c("normal","gross","sehr gross"));size
tonsilen<-glm(strepto~size,family = binomial());tonsilen
summary(tonsilen)

#extra
BBBClub$choice<-as.numeric(BBBClub$choice)
BBBClub$gender<-as.numeric(BBBClub$gender)
BBBClub$lastmonth<-as.numeric(BBBClub$lastmonth)
BBBClub$lastmonth= BBBClub$amount
BBBClub
boxplot(BBBClub~choice+gender+lastmonth,data = BBBClub)
par(mfrow=c(1,2))
for(i in 1:2) {
  boxplot(BBBClub[,i], main=names(BBBClub)[i])
}

