classsexmodww <- glm(tab ~ geschl * klasse, family=binomial)
summary(classsexmodww)
install.packages(effects)
yrequire(effects)
plot(allEffects(classsexmodww), multiline=TRUE)
plot(allEffects(classsexmod))

